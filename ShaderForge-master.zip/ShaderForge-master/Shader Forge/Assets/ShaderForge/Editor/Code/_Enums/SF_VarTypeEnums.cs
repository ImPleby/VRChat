﻿using UnityEngine;
using System.Collections;

public enum FloatPrecision{ Fixed, Half, Float };
public enum CompCount{ c1, c2, c3, c4, c1x1, c2x2, c3x3, c4x4 };